// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6717baf5e4dd.js');self.addEventListener('install',()=>self.skipWaiting());