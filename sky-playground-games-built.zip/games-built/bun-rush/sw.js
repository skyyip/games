// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-21e2297a6cc4.js');self.addEventListener('install',()=>self.skipWaiting());