// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-085ad26945f3.js');self.addEventListener('install',()=>self.skipWaiting());