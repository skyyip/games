// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ed66a6d52d06.js');self.addEventListener('install',()=>self.skipWaiting());