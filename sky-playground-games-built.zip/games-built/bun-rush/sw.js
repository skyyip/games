// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-5436b95c03ec.js');self.addEventListener('install',()=>self.skipWaiting());