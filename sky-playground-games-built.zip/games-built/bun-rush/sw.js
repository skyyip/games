// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d3fa2aa823e2.js');self.addEventListener('install',()=>self.skipWaiting());