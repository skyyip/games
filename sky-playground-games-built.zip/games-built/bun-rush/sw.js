// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-945a5f003dd5.js');self.addEventListener('install',()=>self.skipWaiting());