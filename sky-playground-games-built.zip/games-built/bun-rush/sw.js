// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-3d45cc86dcef.js');self.addEventListener('install',()=>self.skipWaiting());