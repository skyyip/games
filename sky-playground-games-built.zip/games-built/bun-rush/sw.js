// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-371ed9220163.js');self.addEventListener('install',()=>self.skipWaiting());