// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2f6cf22fd4fa.js');self.addEventListener('install',()=>self.skipWaiting());