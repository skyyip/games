// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-8a53de969047.js');self.addEventListener('install',()=>self.skipWaiting());