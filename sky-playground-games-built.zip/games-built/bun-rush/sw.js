// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a7029b01d439.js');self.addEventListener('install',()=>self.skipWaiting());