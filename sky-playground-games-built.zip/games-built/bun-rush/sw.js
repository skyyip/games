// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-197a84f10c90.js');self.addEventListener('install',()=>self.skipWaiting());