// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f6abadca9d19.js');self.addEventListener('install',()=>self.skipWaiting());