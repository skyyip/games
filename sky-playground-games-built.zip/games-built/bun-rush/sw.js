// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d4e531242e4c.js');self.addEventListener('install',()=>self.skipWaiting());