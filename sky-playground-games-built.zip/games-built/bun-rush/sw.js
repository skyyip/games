// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-64e91d911358.js');self.addEventListener('install',()=>self.skipWaiting());