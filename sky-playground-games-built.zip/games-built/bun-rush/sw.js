// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-064088a327c4.js');self.addEventListener('install',()=>self.skipWaiting());