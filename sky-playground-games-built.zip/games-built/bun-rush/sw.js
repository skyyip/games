// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c7cb5ddcff6d.js');self.addEventListener('install',()=>self.skipWaiting());