// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-95852a52269e.js');self.addEventListener('install',()=>self.skipWaiting());