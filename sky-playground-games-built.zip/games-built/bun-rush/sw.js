// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a81c12ae14b6.js');self.addEventListener('install',()=>self.skipWaiting());