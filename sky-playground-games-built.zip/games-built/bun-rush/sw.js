// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ce3d5c94c166.js');self.addEventListener('install',()=>self.skipWaiting());