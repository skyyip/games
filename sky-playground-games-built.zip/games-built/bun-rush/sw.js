// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2290176a6a75.js');self.addEventListener('install',()=>self.skipWaiting());