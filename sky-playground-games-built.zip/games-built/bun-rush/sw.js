// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-624a3290826d.js');self.addEventListener('install',()=>self.skipWaiting());