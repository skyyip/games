// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ebc3025a442a.js');self.addEventListener('install',()=>self.skipWaiting());