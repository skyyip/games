// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-30d5f03156ca.js');self.addEventListener('install',()=>self.skipWaiting());