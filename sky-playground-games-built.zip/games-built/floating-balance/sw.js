// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a213e8847e0d.js');self.addEventListener('install',()=>self.skipWaiting());