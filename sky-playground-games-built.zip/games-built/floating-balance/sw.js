// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-8ebec51eb16b.js');self.addEventListener('install',()=>self.skipWaiting());