// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1a27501d68a6.js');self.addEventListener('install',()=>self.skipWaiting());