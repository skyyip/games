// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-22f44ebe0b66.js');self.addEventListener('install',()=>self.skipWaiting());