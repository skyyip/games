// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9751afded78b.js');self.addEventListener('install',()=>self.skipWaiting());