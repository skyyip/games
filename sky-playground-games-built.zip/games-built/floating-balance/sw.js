// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a11cecf210ac.js');self.addEventListener('install',()=>self.skipWaiting());