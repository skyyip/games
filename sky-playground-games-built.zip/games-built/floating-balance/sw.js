// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-230774dd8762.js');self.addEventListener('install',()=>self.skipWaiting());