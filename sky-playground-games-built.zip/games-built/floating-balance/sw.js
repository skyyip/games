// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-674f8a090a72.js');self.addEventListener('install',()=>self.skipWaiting());