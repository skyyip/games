// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0de27bbe9ad7.js');self.addEventListener('install',()=>self.skipWaiting());