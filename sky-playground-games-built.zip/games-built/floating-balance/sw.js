// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9c97be1845c7.js');self.addEventListener('install',()=>self.skipWaiting());