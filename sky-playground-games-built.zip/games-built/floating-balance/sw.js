// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f686bd3e311a.js');self.addEventListener('install',()=>self.skipWaiting());