// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-294cdf41493a.js');self.addEventListener('install',()=>self.skipWaiting());