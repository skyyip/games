// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f7949cad039b.js');self.addEventListener('install',()=>self.skipWaiting());