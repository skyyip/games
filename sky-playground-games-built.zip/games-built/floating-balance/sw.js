// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-bc19f1a104b6.js');self.addEventListener('install',()=>self.skipWaiting());