// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-af631ac1dc14.js');self.addEventListener('install',()=>self.skipWaiting());