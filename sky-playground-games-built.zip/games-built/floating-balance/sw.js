// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-5c3cc7619d90.js');self.addEventListener('install',()=>self.skipWaiting());