// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-bef26d4c8fa3.js');self.addEventListener('install',()=>self.skipWaiting());