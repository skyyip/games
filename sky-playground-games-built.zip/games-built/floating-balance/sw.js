// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-15b0a7478279.js');self.addEventListener('install',()=>self.skipWaiting());