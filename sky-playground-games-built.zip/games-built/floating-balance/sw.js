// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f65849b19bc1.js');self.addEventListener('install',()=>self.skipWaiting());