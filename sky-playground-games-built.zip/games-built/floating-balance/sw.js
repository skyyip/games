// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f6c445d6fd6b.js');self.addEventListener('install',()=>self.skipWaiting());