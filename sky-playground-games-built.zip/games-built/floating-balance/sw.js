// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7846c7ce8bf0.js');self.addEventListener('install',()=>self.skipWaiting());