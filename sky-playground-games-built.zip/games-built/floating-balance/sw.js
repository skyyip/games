// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ef229839e8c8.js');self.addEventListener('install',()=>self.skipWaiting());