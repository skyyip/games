// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-76f9b3a79197.js');self.addEventListener('install',()=>self.skipWaiting());