// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e8ebb6ce47cb.js');self.addEventListener('install',()=>self.skipWaiting());