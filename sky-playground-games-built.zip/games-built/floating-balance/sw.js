// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b65720265b89.js');self.addEventListener('install',()=>self.skipWaiting());