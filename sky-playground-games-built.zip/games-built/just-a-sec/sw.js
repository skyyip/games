// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-769d3832cc7d.js');self.addEventListener('install',()=>self.skipWaiting());