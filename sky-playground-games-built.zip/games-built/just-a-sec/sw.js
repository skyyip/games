// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9811846a9d92.js');self.addEventListener('install',()=>self.skipWaiting());