// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-620e6aedd114.js');self.addEventListener('install',()=>self.skipWaiting());