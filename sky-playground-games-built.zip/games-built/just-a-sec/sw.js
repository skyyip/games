// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d3a97bd254df.js');self.addEventListener('install',()=>self.skipWaiting());