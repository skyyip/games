// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-837e0f0f7062.js');self.addEventListener('install',()=>self.skipWaiting());