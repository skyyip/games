// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c67a9ba295c2.js');self.addEventListener('install',()=>self.skipWaiting());