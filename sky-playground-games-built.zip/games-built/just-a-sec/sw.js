// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-fb1062e5e72b.js');self.addEventListener('install',()=>self.skipWaiting());