// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9536781027ec.js');self.addEventListener('install',()=>self.skipWaiting());