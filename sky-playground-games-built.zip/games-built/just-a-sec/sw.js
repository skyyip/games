// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-992826121fc7.js');self.addEventListener('install',()=>self.skipWaiting());