// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-56580b78d638.js');self.addEventListener('install',()=>self.skipWaiting());