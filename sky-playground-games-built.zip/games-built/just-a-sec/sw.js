// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-3b9f7ef21cbd.js');self.addEventListener('install',()=>self.skipWaiting());