// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-67172098e3af.js');self.addEventListener('install',()=>self.skipWaiting());