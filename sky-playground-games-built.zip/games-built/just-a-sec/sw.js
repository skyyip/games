// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ee616528b46f.js');self.addEventListener('install',()=>self.skipWaiting());