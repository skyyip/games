// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-85cd64b97a0c.js');self.addEventListener('install',()=>self.skipWaiting());