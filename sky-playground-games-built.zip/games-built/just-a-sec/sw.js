// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1c6f21f1786f.js');self.addEventListener('install',()=>self.skipWaiting());