// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-793ece576945.js');self.addEventListener('install',()=>self.skipWaiting());