// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-206c5551caf4.js');self.addEventListener('install',()=>self.skipWaiting());