// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e6cfa27825c1.js');self.addEventListener('install',()=>self.skipWaiting());