// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-34c438a8a5a4.js');self.addEventListener('install',()=>self.skipWaiting());