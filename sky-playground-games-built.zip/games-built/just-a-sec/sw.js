// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-8a26855ecaa5.js');self.addEventListener('install',()=>self.skipWaiting());