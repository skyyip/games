// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-86c59f784f16.js');self.addEventListener('install',()=>self.skipWaiting());