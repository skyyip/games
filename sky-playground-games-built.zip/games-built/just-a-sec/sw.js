// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-24f7690840f8.js');self.addEventListener('install',()=>self.skipWaiting());