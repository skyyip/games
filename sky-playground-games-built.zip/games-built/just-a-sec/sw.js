// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9271c32196c6.js');self.addEventListener('install',()=>self.skipWaiting());