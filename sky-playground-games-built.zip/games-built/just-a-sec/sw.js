// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b0b80b2ef7e9.js');self.addEventListener('install',()=>self.skipWaiting());