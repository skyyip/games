// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-169a7f9c2b7d.js');self.addEventListener('install',()=>self.skipWaiting());