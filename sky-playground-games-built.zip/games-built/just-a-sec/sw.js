// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2ca66e7be0db.js');self.addEventListener('install',()=>self.skipWaiting());