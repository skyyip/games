// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7f0f39a78ca9.js');self.addEventListener('install',()=>self.skipWaiting());