// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0eb638cb573b.js');self.addEventListener('install',()=>self.skipWaiting());