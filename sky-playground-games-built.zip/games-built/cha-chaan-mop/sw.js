// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c111c61b1223.js');self.addEventListener('install',()=>self.skipWaiting());