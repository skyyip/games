// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7ff22a7064dd.js');self.addEventListener('install',()=>self.skipWaiting());