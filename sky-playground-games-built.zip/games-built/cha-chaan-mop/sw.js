// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-852d680a1588.js');self.addEventListener('install',()=>self.skipWaiting());