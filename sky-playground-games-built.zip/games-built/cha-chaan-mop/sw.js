// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7ddd46d9f287.js');self.addEventListener('install',()=>self.skipWaiting());