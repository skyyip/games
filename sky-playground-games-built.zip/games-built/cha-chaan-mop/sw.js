// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-751efa532a60.js');self.addEventListener('install',()=>self.skipWaiting());