// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ed50e13c3129.js');self.addEventListener('install',()=>self.skipWaiting());