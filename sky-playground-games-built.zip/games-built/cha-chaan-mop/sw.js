// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-5abb38dfc8f1.js');self.addEventListener('install',()=>self.skipWaiting());