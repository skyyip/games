// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-bd49ba5b2fb8.js');self.addEventListener('install',()=>self.skipWaiting());