// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6579903cd516.js');self.addEventListener('install',()=>self.skipWaiting());