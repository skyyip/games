// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ee27b509f0e2.js');self.addEventListener('install',()=>self.skipWaiting());