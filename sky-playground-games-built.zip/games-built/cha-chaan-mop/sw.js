// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2514170dc247.js');self.addEventListener('install',()=>self.skipWaiting());