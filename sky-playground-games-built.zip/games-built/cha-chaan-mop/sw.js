// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-366dbed5b9f8.js');self.addEventListener('install',()=>self.skipWaiting());