// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-757da740d558.js');self.addEventListener('install',()=>self.skipWaiting());