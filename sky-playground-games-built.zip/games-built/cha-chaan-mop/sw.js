// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-8a0252a4527d.js');self.addEventListener('install',()=>self.skipWaiting());