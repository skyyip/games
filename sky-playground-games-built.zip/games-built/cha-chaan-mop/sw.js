// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-34b6b870c306.js');self.addEventListener('install',()=>self.skipWaiting());