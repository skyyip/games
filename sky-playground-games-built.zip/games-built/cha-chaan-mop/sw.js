// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-907d01c91121.js');self.addEventListener('install',()=>self.skipWaiting());