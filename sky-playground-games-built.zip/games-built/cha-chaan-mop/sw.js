// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b4ae40ad9826.js');self.addEventListener('install',()=>self.skipWaiting());