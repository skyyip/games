// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-52d1239fea32.js');self.addEventListener('install',()=>self.skipWaiting());