// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6c6a6e8b610d.js');self.addEventListener('install',()=>self.skipWaiting());