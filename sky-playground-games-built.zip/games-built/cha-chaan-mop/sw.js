// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-dc8d6d7f8046.js');self.addEventListener('install',()=>self.skipWaiting());