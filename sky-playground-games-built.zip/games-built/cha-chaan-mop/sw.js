// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-bd3dde2a2f2e.js');self.addEventListener('install',()=>self.skipWaiting());