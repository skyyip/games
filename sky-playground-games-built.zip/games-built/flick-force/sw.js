// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-077ebdc7a210.js');self.addEventListener('install',()=>self.skipWaiting());