// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-aec8619d0c7e.js');self.addEventListener('install',()=>self.skipWaiting());