// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-5d7d8f66df28.js');self.addEventListener('install',()=>self.skipWaiting());