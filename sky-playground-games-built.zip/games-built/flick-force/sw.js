// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6ce8bda0c6e6.js');self.addEventListener('install',()=>self.skipWaiting());