// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0fed4f58ce6e.js');self.addEventListener('install',()=>self.skipWaiting());