// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-505d959ea3a6.js');self.addEventListener('install',()=>self.skipWaiting());