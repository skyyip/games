// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0224d8677e59.js');self.addEventListener('install',()=>self.skipWaiting());