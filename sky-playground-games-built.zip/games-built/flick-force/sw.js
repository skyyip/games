// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-4cbec6990c63.js');self.addEventListener('install',()=>self.skipWaiting());