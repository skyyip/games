// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2514bb70d6d8.js');self.addEventListener('install',()=>self.skipWaiting());