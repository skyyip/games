// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2029d9fa71ac.js');self.addEventListener('install',()=>self.skipWaiting());