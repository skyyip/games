// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2c744d0fca64.js');self.addEventListener('install',()=>self.skipWaiting());