// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-734223e2002c.js');self.addEventListener('install',()=>self.skipWaiting());