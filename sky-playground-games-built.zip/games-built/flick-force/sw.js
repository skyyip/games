// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-149d7a7bc65a.js');self.addEventListener('install',()=>self.skipWaiting());