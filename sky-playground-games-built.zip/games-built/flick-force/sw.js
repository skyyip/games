// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-77cd29b1e1e1.js');self.addEventListener('install',()=>self.skipWaiting());