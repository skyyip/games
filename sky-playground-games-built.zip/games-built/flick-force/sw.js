// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c0ef795eecc8.js');self.addEventListener('install',()=>self.skipWaiting());