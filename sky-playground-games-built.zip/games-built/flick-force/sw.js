// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2ca5bed1b41f.js');self.addEventListener('install',()=>self.skipWaiting());