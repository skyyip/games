// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c93896aab65c.js');self.addEventListener('install',()=>self.skipWaiting());