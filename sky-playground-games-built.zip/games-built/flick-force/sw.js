// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2ea29b5ac4ab.js');self.addEventListener('install',()=>self.skipWaiting());