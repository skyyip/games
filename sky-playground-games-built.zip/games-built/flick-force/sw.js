// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ec7a1a36ffa7.js');self.addEventListener('install',()=>self.skipWaiting());