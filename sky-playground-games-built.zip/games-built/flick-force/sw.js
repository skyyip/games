// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e1a153315da7.js');self.addEventListener('install',()=>self.skipWaiting());