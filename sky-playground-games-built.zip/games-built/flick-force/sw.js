// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6de5f1102753.js');self.addEventListener('install',()=>self.skipWaiting());