// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-194839477017.js');self.addEventListener('install',()=>self.skipWaiting());