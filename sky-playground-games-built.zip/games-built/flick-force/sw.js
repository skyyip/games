// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f1207290792a.js');self.addEventListener('install',()=>self.skipWaiting());