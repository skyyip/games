// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b0142d0aeb58.js');self.addEventListener('install',()=>self.skipWaiting());