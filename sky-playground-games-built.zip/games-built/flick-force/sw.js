// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-22076e3eb1b4.js');self.addEventListener('install',()=>self.skipWaiting());