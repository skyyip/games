// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e409c2626c7d.js');self.addEventListener('install',()=>self.skipWaiting());