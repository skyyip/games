// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-154d57f2f66f.js');self.addEventListener('install',()=>self.skipWaiting());