// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f6453f3e2c36.js');self.addEventListener('install',()=>self.skipWaiting());