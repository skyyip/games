// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-25d3ac0e0c85.js');self.addEventListener('install',()=>self.skipWaiting());