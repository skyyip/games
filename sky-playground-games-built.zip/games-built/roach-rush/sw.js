// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-04f7137a1bf4.js');self.addEventListener('install',()=>self.skipWaiting());