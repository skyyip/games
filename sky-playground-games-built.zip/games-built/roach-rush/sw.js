// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b6f2afb3a1fd.js');self.addEventListener('install',()=>self.skipWaiting());