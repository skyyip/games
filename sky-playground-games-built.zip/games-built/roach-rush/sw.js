// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b7f7bacd7e30.js');self.addEventListener('install',()=>self.skipWaiting());