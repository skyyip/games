// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7271d3bcbd04.js');self.addEventListener('install',()=>self.skipWaiting());