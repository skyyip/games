// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a6e0729f7e4d.js');self.addEventListener('install',()=>self.skipWaiting());