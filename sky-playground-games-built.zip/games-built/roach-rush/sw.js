// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-13ebbca111f7.js');self.addEventListener('install',()=>self.skipWaiting());