// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-be8716aa170a.js');self.addEventListener('install',()=>self.skipWaiting());