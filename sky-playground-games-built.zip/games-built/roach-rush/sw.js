// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-114dba7da9bc.js');self.addEventListener('install',()=>self.skipWaiting());