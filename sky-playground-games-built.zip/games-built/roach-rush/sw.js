// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c0951b7cae71.js');self.addEventListener('install',()=>self.skipWaiting());