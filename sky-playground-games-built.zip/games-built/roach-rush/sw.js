// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e57383d78165.js');self.addEventListener('install',()=>self.skipWaiting());