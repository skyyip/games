// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-712e4a8cf4cd.js');self.addEventListener('install',()=>self.skipWaiting());