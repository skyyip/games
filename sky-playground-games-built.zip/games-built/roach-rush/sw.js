// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b37248bac29a.js');self.addEventListener('install',()=>self.skipWaiting());