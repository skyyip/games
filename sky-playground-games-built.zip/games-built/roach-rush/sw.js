// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-8f93e4396f96.js');self.addEventListener('install',()=>self.skipWaiting());