// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-8d49960a559e.js');self.addEventListener('install',()=>self.skipWaiting());