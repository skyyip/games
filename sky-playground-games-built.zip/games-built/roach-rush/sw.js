// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-bd00109574f9.js');self.addEventListener('install',()=>self.skipWaiting());