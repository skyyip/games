// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-8a15ccf2fccd.js');self.addEventListener('install',()=>self.skipWaiting());