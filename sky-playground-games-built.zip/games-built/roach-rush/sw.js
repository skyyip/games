// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d51c1a3fd0b5.js');self.addEventListener('install',()=>self.skipWaiting());