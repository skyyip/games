// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c5451fab1787.js');self.addEventListener('install',()=>self.skipWaiting());