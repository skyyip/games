// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b236ffe54087.js');self.addEventListener('install',()=>self.skipWaiting());