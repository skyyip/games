// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-161faf14eacf.js');self.addEventListener('install',()=>self.skipWaiting());