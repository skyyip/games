// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-588299ea68b6.js');self.addEventListener('install',()=>self.skipWaiting());