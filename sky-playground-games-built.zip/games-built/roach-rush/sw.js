// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f982429e9a08.js');self.addEventListener('install',()=>self.skipWaiting());