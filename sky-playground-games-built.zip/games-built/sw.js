// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e1343be3ae4b.js');self.addEventListener('install',()=>self.skipWaiting());