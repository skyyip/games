// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ecc490942a9d.js');self.addEventListener('install',()=>self.skipWaiting());