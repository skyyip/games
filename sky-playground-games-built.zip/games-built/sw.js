// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-5336cd979425.js');self.addEventListener('install',()=>self.skipWaiting());