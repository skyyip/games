// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e977a9c5208a.js');self.addEventListener('install',()=>self.skipWaiting());