// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-502b0cdd1089.js');self.addEventListener('install',()=>self.skipWaiting());