// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-5b69f9e61ab5.js');self.addEventListener('install',()=>self.skipWaiting());