// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1fad7de47ce8.js');self.addEventListener('install',()=>self.skipWaiting());