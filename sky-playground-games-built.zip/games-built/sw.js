// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2fee50e952b8.js');self.addEventListener('install',()=>self.skipWaiting());