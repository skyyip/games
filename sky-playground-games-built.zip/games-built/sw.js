// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ba5080cb14b7.js');self.addEventListener('install',()=>self.skipWaiting());