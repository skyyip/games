// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6397cb545557.js');self.addEventListener('install',()=>self.skipWaiting());