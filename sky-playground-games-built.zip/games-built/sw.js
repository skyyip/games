// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2987e6686fdc.js');self.addEventListener('install',()=>self.skipWaiting());