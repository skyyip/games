// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f9ffc2ab6b90.js');self.addEventListener('install',()=>self.skipWaiting());