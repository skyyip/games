// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c349c811207c.js');self.addEventListener('install',()=>self.skipWaiting());