// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e4d1f566ec61.js');self.addEventListener('install',()=>self.skipWaiting());