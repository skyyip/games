// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9f02fc3876fc.js');self.addEventListener('install',()=>self.skipWaiting());