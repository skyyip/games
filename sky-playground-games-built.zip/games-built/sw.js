// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-8b87438395c7.js');self.addEventListener('install',()=>self.skipWaiting());