// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6bc27f45738d.js');self.addEventListener('install',()=>self.skipWaiting());