// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c27d59d8aea0.js');self.addEventListener('install',()=>self.skipWaiting());