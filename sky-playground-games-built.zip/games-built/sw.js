// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-732e8ecb5892.js');self.addEventListener('install',()=>self.skipWaiting());