// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-dd2700ce01b3.js');self.addEventListener('install',()=>self.skipWaiting());