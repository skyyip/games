// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e39a14bf19c1.js');self.addEventListener('install',()=>self.skipWaiting());