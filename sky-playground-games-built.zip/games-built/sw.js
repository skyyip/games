// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-18caf458b090.js');self.addEventListener('install',()=>self.skipWaiting());