// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b7a108ce861e.js');self.addEventListener('install',()=>self.skipWaiting());