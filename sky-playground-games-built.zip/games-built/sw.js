// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-dd5b8c75b134.js');self.addEventListener('install',()=>self.skipWaiting());