import"./chunk-G7XMJZLX.js";var o=()=>import("./chunk-CXALTQMA.js");export{o as loadFirestoreSDK};
