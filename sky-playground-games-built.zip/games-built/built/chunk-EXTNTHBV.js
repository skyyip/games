import{b as a,c as b,d as c}from"./chunk-Y44QGWU4.js";import"./chunk-G7XMJZLX.js";export{b as authClient,a as configured,c as dataClient};
