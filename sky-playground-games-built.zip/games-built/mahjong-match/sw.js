// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-01e8487d8eb4.js');self.addEventListener('install',()=>self.skipWaiting());