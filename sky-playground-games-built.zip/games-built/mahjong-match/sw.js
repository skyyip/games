// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ce583462510b.js');self.addEventListener('install',()=>self.skipWaiting());