// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-8f3848ae72bd.js');self.addEventListener('install',()=>self.skipWaiting());