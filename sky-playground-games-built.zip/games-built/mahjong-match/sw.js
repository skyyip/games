// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-154d1f07bfa5.js');self.addEventListener('install',()=>self.skipWaiting());