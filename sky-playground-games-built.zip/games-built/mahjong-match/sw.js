// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c86173a575c3.js');self.addEventListener('install',()=>self.skipWaiting());