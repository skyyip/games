// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c500179f48b5.js');self.addEventListener('install',()=>self.skipWaiting());