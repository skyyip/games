// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2bbcb5b21d66.js');self.addEventListener('install',()=>self.skipWaiting());