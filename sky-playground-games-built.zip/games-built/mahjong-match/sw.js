// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9e88c3b2959a.js');self.addEventListener('install',()=>self.skipWaiting());