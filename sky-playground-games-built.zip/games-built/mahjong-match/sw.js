// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9f7a0ade5fa6.js');self.addEventListener('install',()=>self.skipWaiting());