// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2722f8e0bd22.js');self.addEventListener('install',()=>self.skipWaiting());