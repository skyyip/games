// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f1f9a1f0d6ee.js');self.addEventListener('install',()=>self.skipWaiting());