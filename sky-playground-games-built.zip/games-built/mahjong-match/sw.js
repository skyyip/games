// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-58dcd5d99898.js');self.addEventListener('install',()=>self.skipWaiting());