// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-dd79dd3ec717.js');self.addEventListener('install',()=>self.skipWaiting());