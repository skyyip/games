// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-8bc4a274d6dd.js');self.addEventListener('install',()=>self.skipWaiting());