// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6028ddd6aa64.js');self.addEventListener('install',()=>self.skipWaiting());