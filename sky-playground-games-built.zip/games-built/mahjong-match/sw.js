// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6cc55b6b8923.js');self.addEventListener('install',()=>self.skipWaiting());