// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-261d0a92ea82.js');self.addEventListener('install',()=>self.skipWaiting());