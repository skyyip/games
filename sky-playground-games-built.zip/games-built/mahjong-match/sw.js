// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1d0dcb6831ed.js');self.addEventListener('install',()=>self.skipWaiting());