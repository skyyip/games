// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-5c8151cda6f5.js');self.addEventListener('install',()=>self.skipWaiting());