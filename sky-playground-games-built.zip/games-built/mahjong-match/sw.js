// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ccacb08a366b.js');self.addEventListener('install',()=>self.skipWaiting());