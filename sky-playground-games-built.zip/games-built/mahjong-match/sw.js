// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-34007438eeef.js');self.addEventListener('install',()=>self.skipWaiting());