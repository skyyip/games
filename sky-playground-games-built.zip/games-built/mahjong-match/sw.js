// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9497f203825d.js');self.addEventListener('install',()=>self.skipWaiting());