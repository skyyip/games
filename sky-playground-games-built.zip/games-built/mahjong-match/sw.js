// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-479e9c8e58fd.js');self.addEventListener('install',()=>self.skipWaiting());