// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b2d9880cc20e.js');self.addEventListener('install',()=>self.skipWaiting());