// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7884d301d6da.js');self.addEventListener('install',()=>self.skipWaiting());