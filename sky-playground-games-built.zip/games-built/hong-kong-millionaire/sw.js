// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c733d7661ea0.js');self.addEventListener('install',()=>self.skipWaiting());