// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a8d26d2aba2c.js');self.addEventListener('install',()=>self.skipWaiting());