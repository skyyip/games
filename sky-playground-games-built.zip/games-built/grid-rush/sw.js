// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2aeb6b2b9466.js');self.addEventListener('install',()=>self.skipWaiting());