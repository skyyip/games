// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a559ac563b26.js');self.addEventListener('install',()=>self.skipWaiting());