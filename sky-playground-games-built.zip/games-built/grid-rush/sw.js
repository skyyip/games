// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-4ad321f00584.js');self.addEventListener('install',()=>self.skipWaiting());