// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e2bf4bbf05c4.js');self.addEventListener('install',()=>self.skipWaiting());