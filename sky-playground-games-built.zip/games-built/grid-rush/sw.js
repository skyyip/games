// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c21bff65f458.js');self.addEventListener('install',()=>self.skipWaiting());