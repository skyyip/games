// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9645c1303591.js');self.addEventListener('install',()=>self.skipWaiting());