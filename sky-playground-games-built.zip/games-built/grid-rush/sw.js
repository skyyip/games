// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-990f2963058f.js');self.addEventListener('install',()=>self.skipWaiting());