// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-99eea4ef4edb.js');self.addEventListener('install',()=>self.skipWaiting());