// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-34d3e38bfbb9.js');self.addEventListener('install',()=>self.skipWaiting());