// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-942783e1c03e.js');self.addEventListener('install',()=>self.skipWaiting());