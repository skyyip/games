// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d2332de5cb46.js');self.addEventListener('install',()=>self.skipWaiting());