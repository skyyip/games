// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ae3199e352f4.js');self.addEventListener('install',()=>self.skipWaiting());