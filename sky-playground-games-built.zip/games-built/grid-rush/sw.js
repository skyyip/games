// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ade6231c6c58.js');self.addEventListener('install',()=>self.skipWaiting());