// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-4fd32ff84653.js');self.addEventListener('install',()=>self.skipWaiting());