// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a9fc6dc24fb1.js');self.addEventListener('install',()=>self.skipWaiting());