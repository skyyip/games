// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ec84ed058a14.js');self.addEventListener('install',()=>self.skipWaiting());