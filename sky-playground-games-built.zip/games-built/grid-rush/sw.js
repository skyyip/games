// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-fd79efb83e97.js');self.addEventListener('install',()=>self.skipWaiting());