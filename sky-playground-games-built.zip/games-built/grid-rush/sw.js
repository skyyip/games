// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f406abdd2acb.js');self.addEventListener('install',()=>self.skipWaiting());