// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-587d27b78af3.js');self.addEventListener('install',()=>self.skipWaiting());