// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-3b1cb2abb296.js');self.addEventListener('install',()=>self.skipWaiting());