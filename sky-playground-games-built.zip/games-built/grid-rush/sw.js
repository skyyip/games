// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-234a12dfad24.js');self.addEventListener('install',()=>self.skipWaiting());