// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f083ec3b5bce.js');self.addEventListener('install',()=>self.skipWaiting());