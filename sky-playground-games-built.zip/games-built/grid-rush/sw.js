// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0580f1fa6683.js');self.addEventListener('install',()=>self.skipWaiting());