// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ac3950cc173e.js');self.addEventListener('install',()=>self.skipWaiting());