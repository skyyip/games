// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-03bf8b0f9c80.js');self.addEventListener('install',()=>self.skipWaiting());