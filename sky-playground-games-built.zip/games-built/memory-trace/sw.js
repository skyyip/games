// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e255c50c0376.js');self.addEventListener('install',()=>self.skipWaiting());