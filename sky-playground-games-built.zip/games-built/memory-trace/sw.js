// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b8df60060013.js');self.addEventListener('install',()=>self.skipWaiting());