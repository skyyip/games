// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9dec266e9e78.js');self.addEventListener('install',()=>self.skipWaiting());