// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-99d3eca6fb1c.js');self.addEventListener('install',()=>self.skipWaiting());