// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2c2110bf07f0.js');self.addEventListener('install',()=>self.skipWaiting());