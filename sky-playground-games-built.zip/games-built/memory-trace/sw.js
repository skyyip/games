// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-4dd083c465fa.js');self.addEventListener('install',()=>self.skipWaiting());