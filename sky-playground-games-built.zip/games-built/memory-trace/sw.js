// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-5c91d1a6846a.js');self.addEventListener('install',()=>self.skipWaiting());