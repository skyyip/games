// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ba03c0d47894.js');self.addEventListener('install',()=>self.skipWaiting());