// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-93de726b5f37.js');self.addEventListener('install',()=>self.skipWaiting());