// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-8072e2a99fb7.js');self.addEventListener('install',()=>self.skipWaiting());