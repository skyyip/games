// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-081c52e6dcaa.js');self.addEventListener('install',()=>self.skipWaiting());