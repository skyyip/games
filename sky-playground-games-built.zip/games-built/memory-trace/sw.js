// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c94b5d6466e6.js');self.addEventListener('install',()=>self.skipWaiting());