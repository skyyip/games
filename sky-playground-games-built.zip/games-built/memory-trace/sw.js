// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-912ef1a302d6.js');self.addEventListener('install',()=>self.skipWaiting());