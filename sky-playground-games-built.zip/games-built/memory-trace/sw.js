// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-89b06ff48b92.js');self.addEventListener('install',()=>self.skipWaiting());