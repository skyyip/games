// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ba506c861661.js');self.addEventListener('install',()=>self.skipWaiting());