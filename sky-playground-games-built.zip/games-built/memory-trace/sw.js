// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a70a288cc30a.js');self.addEventListener('install',()=>self.skipWaiting());