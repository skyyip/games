// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-99bdf1f7022a.js');self.addEventListener('install',()=>self.skipWaiting());