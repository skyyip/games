// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-57410de59b5a.js');self.addEventListener('install',()=>self.skipWaiting());