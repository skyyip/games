// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0e0edcae6b7e.js');self.addEventListener('install',()=>self.skipWaiting());