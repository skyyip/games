// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-84d4db074573.js');self.addEventListener('install',()=>self.skipWaiting());