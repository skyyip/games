// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-5a570b5cc01e.js');self.addEventListener('install',()=>self.skipWaiting());