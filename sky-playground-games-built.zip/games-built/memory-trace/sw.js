// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-bc041c54289e.js');self.addEventListener('install',()=>self.skipWaiting());