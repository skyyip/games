// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0023df4e616c.js');self.addEventListener('install',()=>self.skipWaiting());