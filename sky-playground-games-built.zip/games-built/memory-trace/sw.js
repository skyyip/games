// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-91e88048c457.js');self.addEventListener('install',()=>self.skipWaiting());