// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1c7871b0fb8d.js');self.addEventListener('install',()=>self.skipWaiting());