// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-48767b63bc46.js');self.addEventListener('install',()=>self.skipWaiting());