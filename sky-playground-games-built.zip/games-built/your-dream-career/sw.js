// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1e8774d31bb8.js');self.addEventListener('install',()=>self.skipWaiting());