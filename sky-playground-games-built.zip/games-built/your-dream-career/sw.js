// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-5689b18f1f2f.js');self.addEventListener('install',()=>self.skipWaiting());