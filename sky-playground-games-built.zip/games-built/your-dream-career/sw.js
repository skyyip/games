// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d13a055d4c89.js');self.addEventListener('install',()=>self.skipWaiting());