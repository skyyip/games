// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-df9fafe1b6d9.js');self.addEventListener('install',()=>self.skipWaiting());