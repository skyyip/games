// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1d5811a045f0.js');self.addEventListener('install',()=>self.skipWaiting());