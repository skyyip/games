// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0a22e1764455.js');self.addEventListener('install',()=>self.skipWaiting());