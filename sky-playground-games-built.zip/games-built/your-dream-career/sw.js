// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2210c529da93.js');self.addEventListener('install',()=>self.skipWaiting());