// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-77c63e55a07d.js');self.addEventListener('install',()=>self.skipWaiting());