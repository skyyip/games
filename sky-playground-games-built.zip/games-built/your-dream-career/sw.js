// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e25e9425b5ae.js');self.addEventListener('install',()=>self.skipWaiting());