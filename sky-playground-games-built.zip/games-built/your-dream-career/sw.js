// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f67714b7696e.js');self.addEventListener('install',()=>self.skipWaiting());