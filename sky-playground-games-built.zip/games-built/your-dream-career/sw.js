// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c7a03fe9034c.js');self.addEventListener('install',()=>self.skipWaiting());