// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-04765ba5ff53.js');self.addEventListener('install',()=>self.skipWaiting());