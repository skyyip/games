// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1698f18d7d87.js');self.addEventListener('install',()=>self.skipWaiting());