// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-89bdf841ada0.js');self.addEventListener('install',()=>self.skipWaiting());