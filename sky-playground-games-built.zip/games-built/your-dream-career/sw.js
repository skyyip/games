// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-09aacaa243a8.js');self.addEventListener('install',()=>self.skipWaiting());