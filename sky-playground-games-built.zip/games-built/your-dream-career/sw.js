// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7008e2cac4ac.js');self.addEventListener('install',()=>self.skipWaiting());