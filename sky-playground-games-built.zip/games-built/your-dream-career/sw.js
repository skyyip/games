// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-79bbb539d7e6.js');self.addEventListener('install',()=>self.skipWaiting());