// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-10e85838d88d.js');self.addEventListener('install',()=>self.skipWaiting());