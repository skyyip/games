// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6621df755528.js');self.addEventListener('install',()=>self.skipWaiting());