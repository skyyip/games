// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1cd6ed0cf3ff.js');self.addEventListener('install',()=>self.skipWaiting());