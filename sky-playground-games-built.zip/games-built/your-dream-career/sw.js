// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c76a9a1b031c.js');self.addEventListener('install',()=>self.skipWaiting());