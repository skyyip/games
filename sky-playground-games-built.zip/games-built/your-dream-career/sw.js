// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-285c4701c67c.js');self.addEventListener('install',()=>self.skipWaiting());