// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a43c0320aef5.js');self.addEventListener('install',()=>self.skipWaiting());