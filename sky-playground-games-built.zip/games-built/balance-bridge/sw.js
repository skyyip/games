// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-4e7893f44009.js');self.addEventListener('install',()=>self.skipWaiting());