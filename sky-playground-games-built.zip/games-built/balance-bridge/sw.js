// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6471f9288fdc.js');self.addEventListener('install',()=>self.skipWaiting());