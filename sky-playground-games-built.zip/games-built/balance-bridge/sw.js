// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-3a169d0224b8.js');self.addEventListener('install',()=>self.skipWaiting());