// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d2f738d2788b.js');self.addEventListener('install',()=>self.skipWaiting());