// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-3e155e745e52.js');self.addEventListener('install',()=>self.skipWaiting());