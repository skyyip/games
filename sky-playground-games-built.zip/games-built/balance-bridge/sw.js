// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c83cc8f02e1c.js');self.addEventListener('install',()=>self.skipWaiting());