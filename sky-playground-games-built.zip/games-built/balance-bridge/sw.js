// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c2673de09f0e.js');self.addEventListener('install',()=>self.skipWaiting());