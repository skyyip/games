// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-53e6f278319a.js');self.addEventListener('install',()=>self.skipWaiting());