// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-fa21b6ae8b5a.js');self.addEventListener('install',()=>self.skipWaiting());