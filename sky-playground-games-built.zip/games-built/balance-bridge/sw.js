// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-be22f73f9287.js');self.addEventListener('install',()=>self.skipWaiting());