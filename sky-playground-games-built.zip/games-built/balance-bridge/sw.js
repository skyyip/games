// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f08f1453dd5c.js');self.addEventListener('install',()=>self.skipWaiting());