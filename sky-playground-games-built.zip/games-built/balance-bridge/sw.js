// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d26d9686b2b7.js');self.addEventListener('install',()=>self.skipWaiting());