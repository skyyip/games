// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e2783ca61b49.js');self.addEventListener('install',()=>self.skipWaiting());