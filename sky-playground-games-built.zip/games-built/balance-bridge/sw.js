// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7636a321972d.js');self.addEventListener('install',()=>self.skipWaiting());