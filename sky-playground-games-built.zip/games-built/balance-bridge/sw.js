// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-fd578871b8fe.js');self.addEventListener('install',()=>self.skipWaiting());