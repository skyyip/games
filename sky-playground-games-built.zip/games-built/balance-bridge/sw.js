// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-8b378711008b.js');self.addEventListener('install',()=>self.skipWaiting());