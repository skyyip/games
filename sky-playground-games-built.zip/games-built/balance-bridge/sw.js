// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-756e11b73bf3.js');self.addEventListener('install',()=>self.skipWaiting());