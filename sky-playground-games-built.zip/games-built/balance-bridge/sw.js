// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-26b2f3da4ad8.js');self.addEventListener('install',()=>self.skipWaiting());