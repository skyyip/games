// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-4b1c00137fbc.js');self.addEventListener('install',()=>self.skipWaiting());