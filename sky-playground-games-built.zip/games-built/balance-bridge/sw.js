// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-66610cb17ee4.js');self.addEventListener('install',()=>self.skipWaiting());