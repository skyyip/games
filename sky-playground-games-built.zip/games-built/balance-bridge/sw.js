// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-65ec3aea7831.js');self.addEventListener('install',()=>self.skipWaiting());