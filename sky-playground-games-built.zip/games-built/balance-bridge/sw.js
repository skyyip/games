// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6e4e490d59c8.js');self.addEventListener('install',()=>self.skipWaiting());