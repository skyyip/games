// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-3573b22fd8ca.js');self.addEventListener('install',()=>self.skipWaiting());