// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-95e8765e33c0.js');self.addEventListener('install',()=>self.skipWaiting());