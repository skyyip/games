// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-3e12827a6c49.js');self.addEventListener('install',()=>self.skipWaiting());