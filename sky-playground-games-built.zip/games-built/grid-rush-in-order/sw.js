// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-18929bea21a0.js');self.addEventListener('install',()=>self.skipWaiting());