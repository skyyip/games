// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-def46f14e9e0.js');self.addEventListener('install',()=>self.skipWaiting());