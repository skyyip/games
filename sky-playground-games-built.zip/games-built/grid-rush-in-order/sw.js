// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a54eca6b0a22.js');self.addEventListener('install',()=>self.skipWaiting());