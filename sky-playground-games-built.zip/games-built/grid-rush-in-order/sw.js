// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6c7ed39e0847.js');self.addEventListener('install',()=>self.skipWaiting());