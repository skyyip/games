// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-14c6e8e9b0a1.js');self.addEventListener('install',()=>self.skipWaiting());