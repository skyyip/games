// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-50d5151c720c.js');self.addEventListener('install',()=>self.skipWaiting());