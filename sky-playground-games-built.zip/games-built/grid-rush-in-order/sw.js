// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a90cd0963d1f.js');self.addEventListener('install',()=>self.skipWaiting());