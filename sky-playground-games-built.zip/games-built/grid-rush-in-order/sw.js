// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-45133c524614.js');self.addEventListener('install',()=>self.skipWaiting());