// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-4cc843244f3b.js');self.addEventListener('install',()=>self.skipWaiting());