// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9ccfdd2a621c.js');self.addEventListener('install',()=>self.skipWaiting());