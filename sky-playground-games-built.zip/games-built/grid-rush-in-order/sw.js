// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e404e1fe9edb.js');self.addEventListener('install',()=>self.skipWaiting());