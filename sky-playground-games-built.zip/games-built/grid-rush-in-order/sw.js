// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-395d35207067.js');self.addEventListener('install',()=>self.skipWaiting());