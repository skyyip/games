// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-cfc6ae3d2cee.js');self.addEventListener('install',()=>self.skipWaiting());