// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6fab7950720d.js');self.addEventListener('install',()=>self.skipWaiting());