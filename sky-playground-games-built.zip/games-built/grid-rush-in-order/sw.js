// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-5147255aa5f8.js');self.addEventListener('install',()=>self.skipWaiting());