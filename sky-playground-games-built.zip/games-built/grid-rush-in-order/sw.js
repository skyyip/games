// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2871f13f00a8.js');self.addEventListener('install',()=>self.skipWaiting());