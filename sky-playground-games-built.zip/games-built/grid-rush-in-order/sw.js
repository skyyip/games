// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c21104cca9b0.js');self.addEventListener('install',()=>self.skipWaiting());