// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-fb4244fc1d62.js');self.addEventListener('install',()=>self.skipWaiting());