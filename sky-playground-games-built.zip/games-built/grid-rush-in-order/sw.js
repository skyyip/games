// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-dcf9b1f96adf.js');self.addEventListener('install',()=>self.skipWaiting());