// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f375fc806b39.js');self.addEventListener('install',()=>self.skipWaiting());