// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-768ab58764f8.js');self.addEventListener('install',()=>self.skipWaiting());