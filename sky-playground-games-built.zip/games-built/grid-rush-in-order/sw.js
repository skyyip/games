// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-90d906180375.js');self.addEventListener('install',()=>self.skipWaiting());