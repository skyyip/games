// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c68381a96734.js');self.addEventListener('install',()=>self.skipWaiting());