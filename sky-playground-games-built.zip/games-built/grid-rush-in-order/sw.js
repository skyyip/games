// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-adf5082ed222.js');self.addEventListener('install',()=>self.skipWaiting());