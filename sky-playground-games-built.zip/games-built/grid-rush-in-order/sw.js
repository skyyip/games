// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-08639adb16ef.js');self.addEventListener('install',()=>self.skipWaiting());