// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-458e8c82ffba.js');self.addEventListener('install',()=>self.skipWaiting());