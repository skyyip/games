// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-4b00ea8793d1.js');self.addEventListener('install',()=>self.skipWaiting());