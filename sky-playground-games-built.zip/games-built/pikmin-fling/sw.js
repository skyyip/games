// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-4233bbaa0c01.js');self.addEventListener('install',()=>self.skipWaiting());