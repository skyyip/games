// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a4644f30285a.js');self.addEventListener('install',()=>self.skipWaiting());