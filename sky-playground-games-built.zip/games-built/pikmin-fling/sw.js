// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b339176ca08c.js');self.addEventListener('install',()=>self.skipWaiting());