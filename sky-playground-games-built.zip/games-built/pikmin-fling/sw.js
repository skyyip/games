// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c4009e8e74df.js');self.addEventListener('install',()=>self.skipWaiting());