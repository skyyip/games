// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-8ce01334c2ab.js');self.addEventListener('install',()=>self.skipWaiting());