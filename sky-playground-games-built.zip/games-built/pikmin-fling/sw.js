// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e8deade66d8b.js');self.addEventListener('install',()=>self.skipWaiting());