// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-453cc73f53b4.js');self.addEventListener('install',()=>self.skipWaiting());