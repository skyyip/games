// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-90740a0c5d86.js');self.addEventListener('install',()=>self.skipWaiting());