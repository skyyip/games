// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e94526ae61cd.js');self.addEventListener('install',()=>self.skipWaiting());