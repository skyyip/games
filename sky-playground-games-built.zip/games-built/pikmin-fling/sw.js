// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-08b2b69c46ed.js');self.addEventListener('install',()=>self.skipWaiting());