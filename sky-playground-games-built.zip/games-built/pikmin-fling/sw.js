// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ec45685a74d1.js');self.addEventListener('install',()=>self.skipWaiting());