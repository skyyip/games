// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b5c43e0ef1f2.js');self.addEventListener('install',()=>self.skipWaiting());