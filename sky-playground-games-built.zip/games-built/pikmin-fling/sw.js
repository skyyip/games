// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b378cf30283b.js');self.addEventListener('install',()=>self.skipWaiting());