// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2979b2a11a81.js');self.addEventListener('install',()=>self.skipWaiting());