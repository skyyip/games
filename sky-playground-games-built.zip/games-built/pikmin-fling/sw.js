// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-58afe5f8b9ee.js');self.addEventListener('install',()=>self.skipWaiting());