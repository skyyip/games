// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-02f1006fc073.js');self.addEventListener('install',()=>self.skipWaiting());