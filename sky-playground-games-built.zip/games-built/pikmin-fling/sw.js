// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-61db5e26c02f.js');self.addEventListener('install',()=>self.skipWaiting());