// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-dd6980e72858.js');self.addEventListener('install',()=>self.skipWaiting());