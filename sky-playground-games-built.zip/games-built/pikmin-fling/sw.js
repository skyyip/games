// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b90fe108968d.js');self.addEventListener('install',()=>self.skipWaiting());