// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0f8c662da13f.js');self.addEventListener('install',()=>self.skipWaiting());