// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-05a97644c9e5.js');self.addEventListener('install',()=>self.skipWaiting());