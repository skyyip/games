// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-19b461b5c978.js');self.addEventListener('install',()=>self.skipWaiting());