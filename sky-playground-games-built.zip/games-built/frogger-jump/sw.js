// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0466775daa2a.js');self.addEventListener('install',()=>self.skipWaiting());