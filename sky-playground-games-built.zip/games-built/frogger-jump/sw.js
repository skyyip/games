// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-fbc741c888da.js');self.addEventListener('install',()=>self.skipWaiting());