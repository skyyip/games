// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-4ab570cdbc45.js');self.addEventListener('install',()=>self.skipWaiting());