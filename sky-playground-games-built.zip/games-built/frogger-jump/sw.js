// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6e9525b3d276.js');self.addEventListener('install',()=>self.skipWaiting());