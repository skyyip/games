// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-987ffe1963fc.js');self.addEventListener('install',()=>self.skipWaiting());