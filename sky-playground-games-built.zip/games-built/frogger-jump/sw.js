// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0733903051e3.js');self.addEventListener('install',()=>self.skipWaiting());