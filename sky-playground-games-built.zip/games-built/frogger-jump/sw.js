// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6019f3bd126d.js');self.addEventListener('install',()=>self.skipWaiting());