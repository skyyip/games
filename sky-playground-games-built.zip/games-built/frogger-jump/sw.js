// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-529c097b570a.js');self.addEventListener('install',()=>self.skipWaiting());