// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-81e093b1a4a1.js');self.addEventListener('install',()=>self.skipWaiting());