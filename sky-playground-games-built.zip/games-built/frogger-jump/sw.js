// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-5c40f8370547.js');self.addEventListener('install',()=>self.skipWaiting());