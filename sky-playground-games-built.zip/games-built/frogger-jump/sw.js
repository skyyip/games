// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-dc4ea79cc246.js');self.addEventListener('install',()=>self.skipWaiting());