// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-918117c9357d.js');self.addEventListener('install',()=>self.skipWaiting());