// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-924e588b652b.js');self.addEventListener('install',()=>self.skipWaiting());