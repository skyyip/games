// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-10363c02b037.js');self.addEventListener('install',()=>self.skipWaiting());