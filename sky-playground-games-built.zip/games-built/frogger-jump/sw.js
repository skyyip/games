// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-80c4b283be9b.js');self.addEventListener('install',()=>self.skipWaiting());