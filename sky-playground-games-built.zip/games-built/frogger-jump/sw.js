// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-51fc4ec686c0.js');self.addEventListener('install',()=>self.skipWaiting());