// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-04873c067532.js');self.addEventListener('install',()=>self.skipWaiting());