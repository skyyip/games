// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-479e2b81b931.js');self.addEventListener('install',()=>self.skipWaiting());