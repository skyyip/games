// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-bcb9cce6e56b.js');self.addEventListener('install',()=>self.skipWaiting());