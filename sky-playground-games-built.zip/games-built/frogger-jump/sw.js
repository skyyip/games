// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-49d19f9ac9e8.js');self.addEventListener('install',()=>self.skipWaiting());