// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1afb39686c8f.js');self.addEventListener('install',()=>self.skipWaiting());