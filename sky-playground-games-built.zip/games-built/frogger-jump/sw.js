// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b6cd3d367ef1.js');self.addEventListener('install',()=>self.skipWaiting());