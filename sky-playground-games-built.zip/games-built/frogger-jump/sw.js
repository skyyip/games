// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b7a6f8ac9aad.js');self.addEventListener('install',()=>self.skipWaiting());