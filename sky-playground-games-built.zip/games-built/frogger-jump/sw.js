// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d6379e279ee7.js');self.addEventListener('install',()=>self.skipWaiting());