// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-203603511c29.js');self.addEventListener('install',()=>self.skipWaiting());