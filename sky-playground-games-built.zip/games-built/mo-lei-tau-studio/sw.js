// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-99ec862242fe.js');self.addEventListener('install',()=>self.skipWaiting());