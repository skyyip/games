// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b692e3dfab55.js');self.addEventListener('install',()=>self.skipWaiting());