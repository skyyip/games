// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9f95df228cef.js');self.addEventListener('install',()=>self.skipWaiting());