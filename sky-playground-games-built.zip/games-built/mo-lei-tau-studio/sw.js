// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0fe77e75a9b7.js');self.addEventListener('install',()=>self.skipWaiting());