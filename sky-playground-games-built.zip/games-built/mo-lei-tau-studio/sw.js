// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-baed3e972531.js');self.addEventListener('install',()=>self.skipWaiting());