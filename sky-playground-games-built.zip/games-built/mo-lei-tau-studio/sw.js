// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a35584ab6d14.js');self.addEventListener('install',()=>self.skipWaiting());