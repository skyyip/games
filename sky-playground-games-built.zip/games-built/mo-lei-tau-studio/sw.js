// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0495628972d9.js');self.addEventListener('install',()=>self.skipWaiting());