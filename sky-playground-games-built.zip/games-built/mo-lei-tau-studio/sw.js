// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-bbb6312b46ea.js');self.addEventListener('install',()=>self.skipWaiting());