// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e4f3575112cc.js');self.addEventListener('install',()=>self.skipWaiting());