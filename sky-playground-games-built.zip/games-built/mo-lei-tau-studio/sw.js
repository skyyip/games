// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-41cd4922fce3.js');self.addEventListener('install',()=>self.skipWaiting());