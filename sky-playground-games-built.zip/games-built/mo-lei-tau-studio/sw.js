// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7ca998199ada.js');self.addEventListener('install',()=>self.skipWaiting());