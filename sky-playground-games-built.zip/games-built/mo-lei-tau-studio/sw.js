// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d52de7e338c4.js');self.addEventListener('install',()=>self.skipWaiting());