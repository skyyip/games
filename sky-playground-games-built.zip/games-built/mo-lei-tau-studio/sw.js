// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-727e4afdf9b8.js');self.addEventListener('install',()=>self.skipWaiting());