// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-71a8a008c3ac.js');self.addEventListener('install',()=>self.skipWaiting());