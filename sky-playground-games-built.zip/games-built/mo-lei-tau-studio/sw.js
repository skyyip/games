// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-67c261b838d6.js');self.addEventListener('install',()=>self.skipWaiting());