// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-518fd6e8e813.js');self.addEventListener('install',()=>self.skipWaiting());