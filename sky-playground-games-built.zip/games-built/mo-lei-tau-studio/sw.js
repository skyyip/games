// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6976fbd5522e.js');self.addEventListener('install',()=>self.skipWaiting());