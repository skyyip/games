// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-750c6f29c7da.js');self.addEventListener('install',()=>self.skipWaiting());