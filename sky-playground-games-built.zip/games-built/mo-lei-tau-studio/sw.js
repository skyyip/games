// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-3f8d7603a03e.js');self.addEventListener('install',()=>self.skipWaiting());