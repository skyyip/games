// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ec795c24ca0f.js');self.addEventListener('install',()=>self.skipWaiting());