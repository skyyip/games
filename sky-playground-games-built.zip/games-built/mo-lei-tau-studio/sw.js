// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0720191373f1.js');self.addEventListener('install',()=>self.skipWaiting());