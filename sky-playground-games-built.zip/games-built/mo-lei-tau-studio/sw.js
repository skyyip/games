// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f64b276848bc.js');self.addEventListener('install',()=>self.skipWaiting());