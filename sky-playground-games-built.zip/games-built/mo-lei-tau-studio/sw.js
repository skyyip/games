// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-8ab7f9c2e79d.js');self.addEventListener('install',()=>self.skipWaiting());