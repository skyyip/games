// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e41034f84fa9.js');self.addEventListener('install',()=>self.skipWaiting());