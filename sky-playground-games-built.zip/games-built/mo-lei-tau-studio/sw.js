// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-54f43f42cce2.js');self.addEventListener('install',()=>self.skipWaiting());