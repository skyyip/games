// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7512561cd6b9.js');self.addEventListener('install',()=>self.skipWaiting());