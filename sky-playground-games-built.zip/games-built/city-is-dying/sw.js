// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-84562bcceab0.js');self.addEventListener('install',()=>self.skipWaiting());