// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-df1b2a0bc451.js');self.addEventListener('install',()=>self.skipWaiting());