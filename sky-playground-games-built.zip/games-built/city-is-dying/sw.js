// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-aaff66addcdc.js');self.addEventListener('install',()=>self.skipWaiting());