// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d6aa4f1e9cca.js');self.addEventListener('install',()=>self.skipWaiting());