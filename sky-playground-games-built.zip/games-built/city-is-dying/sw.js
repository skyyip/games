// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b420bd887780.js');self.addEventListener('install',()=>self.skipWaiting());