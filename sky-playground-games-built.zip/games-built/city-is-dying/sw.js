// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-240856c48d90.js');self.addEventListener('install',()=>self.skipWaiting());