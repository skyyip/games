// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6efcae05b1b5.js');self.addEventListener('install',()=>self.skipWaiting());