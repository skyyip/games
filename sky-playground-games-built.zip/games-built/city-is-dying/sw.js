// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-eecefe9eb698.js');self.addEventListener('install',()=>self.skipWaiting());