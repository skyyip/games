// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-804bd6115343.js');self.addEventListener('install',()=>self.skipWaiting());