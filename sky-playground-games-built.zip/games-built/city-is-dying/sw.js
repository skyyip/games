// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9a94180c6b75.js');self.addEventListener('install',()=>self.skipWaiting());