// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-4ab89e9ebc86.js');self.addEventListener('install',()=>self.skipWaiting());