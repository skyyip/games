// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-53ba590f9e32.js');self.addEventListener('install',()=>self.skipWaiting());