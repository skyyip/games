// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2b375a710a5b.js');self.addEventListener('install',()=>self.skipWaiting());