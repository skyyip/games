// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-672cab760a5a.js');self.addEventListener('install',()=>self.skipWaiting());