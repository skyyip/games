// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-41fef400cd17.js');self.addEventListener('install',()=>self.skipWaiting());