// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-bd197d60bf56.js');self.addEventListener('install',()=>self.skipWaiting());