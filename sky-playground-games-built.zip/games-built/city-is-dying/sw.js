// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-eee823eb9e1d.js');self.addEventListener('install',()=>self.skipWaiting());