// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-223184e5b681.js');self.addEventListener('install',()=>self.skipWaiting());