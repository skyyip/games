// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-127278e2bcfb.js');self.addEventListener('install',()=>self.skipWaiting());