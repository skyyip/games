// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-fd1ebfe5d6d4.js');self.addEventListener('install',()=>self.skipWaiting());