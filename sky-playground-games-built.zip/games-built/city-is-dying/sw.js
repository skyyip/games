// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6f6cf54b1421.js');self.addEventListener('install',()=>self.skipWaiting());