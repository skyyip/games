// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-34d526880f1f.js');self.addEventListener('install',()=>self.skipWaiting());