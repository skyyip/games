// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a7acea097bf7.js');self.addEventListener('install',()=>self.skipWaiting());