// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d01f9e080fff.js');self.addEventListener('install',()=>self.skipWaiting());