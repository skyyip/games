// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-74aaef2a63bf.js');self.addEventListener('install',()=>self.skipWaiting());