// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-942c5d59a768.js');self.addEventListener('install',()=>self.skipWaiting());