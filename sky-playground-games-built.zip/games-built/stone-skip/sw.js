// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-81af3897ca9f.js');self.addEventListener('install',()=>self.skipWaiting());