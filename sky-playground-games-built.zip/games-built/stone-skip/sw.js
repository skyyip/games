// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-3e0e1d7ff5ad.js');self.addEventListener('install',()=>self.skipWaiting());