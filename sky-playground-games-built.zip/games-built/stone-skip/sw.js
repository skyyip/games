// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b89223ec196e.js');self.addEventListener('install',()=>self.skipWaiting());