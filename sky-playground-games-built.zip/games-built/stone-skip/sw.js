// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ab8b4514e5cb.js');self.addEventListener('install',()=>self.skipWaiting());