// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0be19b5875df.js');self.addEventListener('install',()=>self.skipWaiting());