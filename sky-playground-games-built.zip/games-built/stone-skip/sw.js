// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-35a2f116f22d.js');self.addEventListener('install',()=>self.skipWaiting());