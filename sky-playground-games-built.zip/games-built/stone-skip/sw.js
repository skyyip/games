// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-af59c44a182e.js');self.addEventListener('install',()=>self.skipWaiting());