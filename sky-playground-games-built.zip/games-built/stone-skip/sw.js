// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-fd2dec829159.js');self.addEventListener('install',()=>self.skipWaiting());