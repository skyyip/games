// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-232631778460.js');self.addEventListener('install',()=>self.skipWaiting());