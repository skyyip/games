// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-759766c30509.js');self.addEventListener('install',()=>self.skipWaiting());