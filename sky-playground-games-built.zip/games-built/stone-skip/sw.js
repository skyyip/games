// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-452b889d8739.js');self.addEventListener('install',()=>self.skipWaiting());