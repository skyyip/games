// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ed8bdc8200f0.js');self.addEventListener('install',()=>self.skipWaiting());