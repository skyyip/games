// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9f21523d2349.js');self.addEventListener('install',()=>self.skipWaiting());