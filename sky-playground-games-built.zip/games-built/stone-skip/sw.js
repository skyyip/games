// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-010c58bf0f72.js');self.addEventListener('install',()=>self.skipWaiting());