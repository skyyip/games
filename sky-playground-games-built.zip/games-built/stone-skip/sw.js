// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2f9186afc943.js');self.addEventListener('install',()=>self.skipWaiting());