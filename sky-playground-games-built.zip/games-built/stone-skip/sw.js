// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-88f3257471e3.js');self.addEventListener('install',()=>self.skipWaiting());