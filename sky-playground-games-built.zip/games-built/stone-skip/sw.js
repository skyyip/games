// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-35faf0cc1670.js');self.addEventListener('install',()=>self.skipWaiting());