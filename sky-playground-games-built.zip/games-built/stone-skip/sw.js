// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c96d1a8640e5.js');self.addEventListener('install',()=>self.skipWaiting());