// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-83ef5b0f283f.js');self.addEventListener('install',()=>self.skipWaiting());