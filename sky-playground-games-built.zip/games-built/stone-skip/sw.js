// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-962d4672afd2.js');self.addEventListener('install',()=>self.skipWaiting());