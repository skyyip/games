// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-8d266509b21a.js');self.addEventListener('install',()=>self.skipWaiting());