// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6715517e556d.js');self.addEventListener('install',()=>self.skipWaiting());