// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-fb5434eb2050.js');self.addEventListener('install',()=>self.skipWaiting());