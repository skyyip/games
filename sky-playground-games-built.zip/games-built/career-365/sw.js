// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-235deb5e21a5.js');self.addEventListener('install',()=>self.skipWaiting());