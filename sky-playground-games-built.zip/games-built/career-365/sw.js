// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6c190229158c.js');self.addEventListener('install',()=>self.skipWaiting());