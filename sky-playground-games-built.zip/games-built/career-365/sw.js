// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1c54e9c2ccd6.js');self.addEventListener('install',()=>self.skipWaiting());