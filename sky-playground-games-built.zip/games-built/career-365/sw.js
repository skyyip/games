// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f2c2f7ade9bf.js');self.addEventListener('install',()=>self.skipWaiting());