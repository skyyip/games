// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-546cc4f33167.js');self.addEventListener('install',()=>self.skipWaiting());