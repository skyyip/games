// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a27f11617bae.js');self.addEventListener('install',()=>self.skipWaiting());