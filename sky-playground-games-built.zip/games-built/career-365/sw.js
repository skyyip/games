// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0e0c60d8d147.js');self.addEventListener('install',()=>self.skipWaiting());