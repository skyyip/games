// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d7b9a20fd2a4.js');self.addEventListener('install',()=>self.skipWaiting());