// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a6a039a1b6f8.js');self.addEventListener('install',()=>self.skipWaiting());