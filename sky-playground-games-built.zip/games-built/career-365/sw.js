// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e4a891b74d37.js');self.addEventListener('install',()=>self.skipWaiting());