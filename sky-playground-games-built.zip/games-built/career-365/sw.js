// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-48e809f8d3ce.js');self.addEventListener('install',()=>self.skipWaiting());