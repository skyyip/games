// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d069b4d7224a.js');self.addEventListener('install',()=>self.skipWaiting());