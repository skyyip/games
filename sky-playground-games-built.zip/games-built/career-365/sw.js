// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-709203684a26.js');self.addEventListener('install',()=>self.skipWaiting());