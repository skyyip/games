// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c7367a6da0e7.js');self.addEventListener('install',()=>self.skipWaiting());