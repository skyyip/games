// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7993c128037d.js');self.addEventListener('install',()=>self.skipWaiting());