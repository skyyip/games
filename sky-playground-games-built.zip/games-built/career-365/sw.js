// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-306314d586d5.js');self.addEventListener('install',()=>self.skipWaiting());