// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d71d738d3f41.js');self.addEventListener('install',()=>self.skipWaiting());