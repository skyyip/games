// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e19a8976f2ab.js');self.addEventListener('install',()=>self.skipWaiting());