// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-75a9faf1a70c.js');self.addEventListener('install',()=>self.skipWaiting());