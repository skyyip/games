// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-5787f485db09.js');self.addEventListener('install',()=>self.skipWaiting());