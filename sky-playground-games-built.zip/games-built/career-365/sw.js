// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c3a0868a3a69.js');self.addEventListener('install',()=>self.skipWaiting());