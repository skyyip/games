// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-fd9d9dbd1523.js');self.addEventListener('install',()=>self.skipWaiting());