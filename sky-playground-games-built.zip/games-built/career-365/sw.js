// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-edcec692ef72.js');self.addEventListener('install',()=>self.skipWaiting());