// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-250d6d0b94ec.js');self.addEventListener('install',()=>self.skipWaiting());