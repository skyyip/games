// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-64e1fa35bc2a.js');self.addEventListener('install',()=>self.skipWaiting());