// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-dd4292722366.js');self.addEventListener('install',()=>self.skipWaiting());