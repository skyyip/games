// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-63d5e1537160.js');self.addEventListener('install',()=>self.skipWaiting());