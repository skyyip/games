// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-46d30833d1e7.js');self.addEventListener('install',()=>self.skipWaiting());