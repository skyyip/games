// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a3071b03c6b4.js');self.addEventListener('install',()=>self.skipWaiting());