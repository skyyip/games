// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ccd80630df58.js');self.addEventListener('install',()=>self.skipWaiting());