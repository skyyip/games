// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-656373fbf7fc.js');self.addEventListener('install',()=>self.skipWaiting());