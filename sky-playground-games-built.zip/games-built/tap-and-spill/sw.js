// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-63c3c3f465da.js');self.addEventListener('install',()=>self.skipWaiting());