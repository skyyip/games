// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-fcf4aba8666a.js');self.addEventListener('install',()=>self.skipWaiting());