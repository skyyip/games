// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-bc6158e32b94.js');self.addEventListener('install',()=>self.skipWaiting());