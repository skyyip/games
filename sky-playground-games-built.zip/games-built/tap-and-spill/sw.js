// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-13f0e7e33a8d.js');self.addEventListener('install',()=>self.skipWaiting());