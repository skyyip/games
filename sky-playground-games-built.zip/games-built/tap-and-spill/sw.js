// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1e655d17f7e2.js');self.addEventListener('install',()=>self.skipWaiting());