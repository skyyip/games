// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-741baa079ee0.js');self.addEventListener('install',()=>self.skipWaiting());