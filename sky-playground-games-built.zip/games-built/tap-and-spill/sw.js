// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-63c83352d6a8.js');self.addEventListener('install',()=>self.skipWaiting());