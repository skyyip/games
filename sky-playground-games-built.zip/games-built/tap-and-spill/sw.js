// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-894234cd71d4.js');self.addEventListener('install',()=>self.skipWaiting());