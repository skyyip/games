// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7b6cb2b9fed6.js');self.addEventListener('install',()=>self.skipWaiting());