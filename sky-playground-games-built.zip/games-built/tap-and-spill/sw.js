// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1e5807c2c3f0.js');self.addEventListener('install',()=>self.skipWaiting());