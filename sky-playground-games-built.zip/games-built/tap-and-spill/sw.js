// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-da65ee2f069e.js');self.addEventListener('install',()=>self.skipWaiting());