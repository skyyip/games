// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-033d9ebd84cf.js');self.addEventListener('install',()=>self.skipWaiting());