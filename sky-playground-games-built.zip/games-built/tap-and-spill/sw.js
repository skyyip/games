// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2adba184f984.js');self.addEventListener('install',()=>self.skipWaiting());