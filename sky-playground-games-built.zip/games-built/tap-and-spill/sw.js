// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-33871bd767fe.js');self.addEventListener('install',()=>self.skipWaiting());