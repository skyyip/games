// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-70130b49e256.js');self.addEventListener('install',()=>self.skipWaiting());