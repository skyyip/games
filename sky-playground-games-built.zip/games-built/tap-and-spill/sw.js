// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-30b15064d70f.js');self.addEventListener('install',()=>self.skipWaiting());