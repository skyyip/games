// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a352e5cd5ea6.js');self.addEventListener('install',()=>self.skipWaiting());