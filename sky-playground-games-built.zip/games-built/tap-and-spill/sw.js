// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-fe7095e8e01d.js');self.addEventListener('install',()=>self.skipWaiting());