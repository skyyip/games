// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7a4e82f9981d.js');self.addEventListener('install',()=>self.skipWaiting());