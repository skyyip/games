// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-321f4084005d.js');self.addEventListener('install',()=>self.skipWaiting());