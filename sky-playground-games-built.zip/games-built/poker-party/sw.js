// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d664b8828f1b.js');self.addEventListener('install',()=>self.skipWaiting());