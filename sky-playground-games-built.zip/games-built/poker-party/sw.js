// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c36a61eaa5f5.js');self.addEventListener('install',()=>self.skipWaiting());