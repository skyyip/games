// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d86955e46cc5.js');self.addEventListener('install',()=>self.skipWaiting());