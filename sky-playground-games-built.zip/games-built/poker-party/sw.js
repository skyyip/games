// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9651715fa325.js');self.addEventListener('install',()=>self.skipWaiting());