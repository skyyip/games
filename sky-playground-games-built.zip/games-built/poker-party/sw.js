// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-601413cece5c.js');self.addEventListener('install',()=>self.skipWaiting());