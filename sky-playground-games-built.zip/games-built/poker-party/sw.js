// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9fb9b259e8fc.js');self.addEventListener('install',()=>self.skipWaiting());