// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-bfcb6e3a1e93.js');self.addEventListener('install',()=>self.skipWaiting());