// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-21b3bf1a8bfd.js');self.addEventListener('install',()=>self.skipWaiting());