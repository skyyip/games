// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6843ff710842.js');self.addEventListener('install',()=>self.skipWaiting());