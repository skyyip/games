// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-fc36302ad052.js');self.addEventListener('install',()=>self.skipWaiting());