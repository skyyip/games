// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c5e236b49d44.js');self.addEventListener('install',()=>self.skipWaiting());