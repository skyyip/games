// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-114649e6560c.js');self.addEventListener('install',()=>self.skipWaiting());