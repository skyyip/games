// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-416bc80af249.js');self.addEventListener('install',()=>self.skipWaiting());