// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9449d8b00660.js');self.addEventListener('install',()=>self.skipWaiting());