// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2bf6efec8271.js');self.addEventListener('install',()=>self.skipWaiting());