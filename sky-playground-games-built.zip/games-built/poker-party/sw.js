// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-3c4947ddb051.js');self.addEventListener('install',()=>self.skipWaiting());