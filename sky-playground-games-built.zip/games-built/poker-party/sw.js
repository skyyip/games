// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c20b874bcfb6.js');self.addEventListener('install',()=>self.skipWaiting());