// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a203b2052aba.js');self.addEventListener('install',()=>self.skipWaiting());