// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-615fdc54fee4.js');self.addEventListener('install',()=>self.skipWaiting());