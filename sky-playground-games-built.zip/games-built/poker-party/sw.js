// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-4ddfad0e7576.js');self.addEventListener('install',()=>self.skipWaiting());