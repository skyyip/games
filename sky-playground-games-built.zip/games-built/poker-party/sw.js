// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-fcb2f2462d66.js');self.addEventListener('install',()=>self.skipWaiting());