// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1118dabea02c.js');self.addEventListener('install',()=>self.skipWaiting());