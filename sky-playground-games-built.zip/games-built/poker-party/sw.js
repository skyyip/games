// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ff3d848c9808.js');self.addEventListener('install',()=>self.skipWaiting());