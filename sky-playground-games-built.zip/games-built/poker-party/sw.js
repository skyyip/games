// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-df248e718121.js');self.addEventListener('install',()=>self.skipWaiting());