// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7ada201466bf.js');self.addEventListener('install',()=>self.skipWaiting());