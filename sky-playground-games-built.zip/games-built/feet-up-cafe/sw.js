// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d8075a8ad9d7.js');self.addEventListener('install',()=>self.skipWaiting());