// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f2e682e716b2.js');self.addEventListener('install',()=>self.skipWaiting());