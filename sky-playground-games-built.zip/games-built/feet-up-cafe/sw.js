// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-bdde28c397b0.js');self.addEventListener('install',()=>self.skipWaiting());