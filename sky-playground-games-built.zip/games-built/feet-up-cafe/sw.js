// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-4bb8964cec1e.js');self.addEventListener('install',()=>self.skipWaiting());