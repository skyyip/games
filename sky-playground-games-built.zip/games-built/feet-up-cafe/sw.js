// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-5cdbb2ced73b.js');self.addEventListener('install',()=>self.skipWaiting());