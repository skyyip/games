// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-923735bd191d.js');self.addEventListener('install',()=>self.skipWaiting());