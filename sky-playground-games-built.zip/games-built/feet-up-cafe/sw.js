// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a2f78a3e2889.js');self.addEventListener('install',()=>self.skipWaiting());