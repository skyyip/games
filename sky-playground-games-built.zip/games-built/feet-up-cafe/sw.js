// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6cfec350a60e.js');self.addEventListener('install',()=>self.skipWaiting());