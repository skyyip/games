// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-3159d1232f57.js');self.addEventListener('install',()=>self.skipWaiting());