// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9146ef7e1fd6.js');self.addEventListener('install',()=>self.skipWaiting());