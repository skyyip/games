// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-824604a0562d.js');self.addEventListener('install',()=>self.skipWaiting());