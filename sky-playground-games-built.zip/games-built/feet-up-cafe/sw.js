// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b28de4f9cbd2.js');self.addEventListener('install',()=>self.skipWaiting());