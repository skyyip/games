// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f8e49ce9d5cc.js');self.addEventListener('install',()=>self.skipWaiting());