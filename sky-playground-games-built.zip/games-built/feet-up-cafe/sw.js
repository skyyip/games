// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-585fe2bf541c.js');self.addEventListener('install',()=>self.skipWaiting());