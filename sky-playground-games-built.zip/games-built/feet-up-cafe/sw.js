// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e3205c5a6c47.js');self.addEventListener('install',()=>self.skipWaiting());