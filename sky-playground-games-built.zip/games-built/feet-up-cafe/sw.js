// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e3a81d5ea800.js');self.addEventListener('install',()=>self.skipWaiting());