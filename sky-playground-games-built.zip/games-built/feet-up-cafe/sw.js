// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1f6cb6d76c7e.js');self.addEventListener('install',()=>self.skipWaiting());