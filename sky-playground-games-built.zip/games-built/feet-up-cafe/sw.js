// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9f8c0b735e31.js');self.addEventListener('install',()=>self.skipWaiting());