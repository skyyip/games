// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-3f78eb3d17f7.js');self.addEventListener('install',()=>self.skipWaiting());