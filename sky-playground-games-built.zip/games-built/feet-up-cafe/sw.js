// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0a35c2c3ee4e.js');self.addEventListener('install',()=>self.skipWaiting());