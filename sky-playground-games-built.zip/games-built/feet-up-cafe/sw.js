// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d2ca744f8458.js');self.addEventListener('install',()=>self.skipWaiting());