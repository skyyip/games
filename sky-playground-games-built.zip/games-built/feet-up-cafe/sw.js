// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e20d44d35f5e.js');self.addEventListener('install',()=>self.skipWaiting());