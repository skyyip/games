// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-82b48cdfe660.js');self.addEventListener('install',()=>self.skipWaiting());