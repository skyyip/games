// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7100440f68f3.js');self.addEventListener('install',()=>self.skipWaiting());