// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9fb2d4ee91ae.js');self.addEventListener('install',()=>self.skipWaiting());