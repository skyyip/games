// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0dee77507f3b.js');self.addEventListener('install',()=>self.skipWaiting());