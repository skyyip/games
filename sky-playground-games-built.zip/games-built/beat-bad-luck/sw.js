// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9351377936e3.js');self.addEventListener('install',()=>self.skipWaiting());