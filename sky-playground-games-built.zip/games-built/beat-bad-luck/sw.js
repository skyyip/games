// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-37c73c4f7bba.js');self.addEventListener('install',()=>self.skipWaiting());