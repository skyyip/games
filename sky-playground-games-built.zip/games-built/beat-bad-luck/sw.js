// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-70f4ef01851c.js');self.addEventListener('install',()=>self.skipWaiting());