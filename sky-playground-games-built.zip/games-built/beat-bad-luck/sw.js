// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9261d8852b7a.js');self.addEventListener('install',()=>self.skipWaiting());