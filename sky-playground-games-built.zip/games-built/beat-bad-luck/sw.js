// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a72ff8377b4d.js');self.addEventListener('install',()=>self.skipWaiting());