// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-705e1c378b01.js');self.addEventListener('install',()=>self.skipWaiting());