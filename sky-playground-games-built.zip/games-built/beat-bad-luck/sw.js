// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1f5c0e350430.js');self.addEventListener('install',()=>self.skipWaiting());