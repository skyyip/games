// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-660bb54113ad.js');self.addEventListener('install',()=>self.skipWaiting());