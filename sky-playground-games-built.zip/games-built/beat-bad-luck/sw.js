// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-87d26c29a471.js');self.addEventListener('install',()=>self.skipWaiting());