// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1563a1caf4f7.js');self.addEventListener('install',()=>self.skipWaiting());