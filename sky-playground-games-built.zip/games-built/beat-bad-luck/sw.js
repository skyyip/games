// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-95cea99536fb.js');self.addEventListener('install',()=>self.skipWaiting());