// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6e2d35850834.js');self.addEventListener('install',()=>self.skipWaiting());