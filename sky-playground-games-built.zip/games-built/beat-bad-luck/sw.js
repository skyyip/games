// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-fc6b71183c58.js');self.addEventListener('install',()=>self.skipWaiting());