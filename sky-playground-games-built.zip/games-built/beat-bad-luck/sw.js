// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ae55ebe7dabb.js');self.addEventListener('install',()=>self.skipWaiting());