// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ccdcfd159ab8.js');self.addEventListener('install',()=>self.skipWaiting());