// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-47fede5e84b0.js');self.addEventListener('install',()=>self.skipWaiting());