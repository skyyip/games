// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-8ba523244605.js');self.addEventListener('install',()=>self.skipWaiting());