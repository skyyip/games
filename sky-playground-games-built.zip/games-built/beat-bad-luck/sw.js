// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e7d9d36493b3.js');self.addEventListener('install',()=>self.skipWaiting());