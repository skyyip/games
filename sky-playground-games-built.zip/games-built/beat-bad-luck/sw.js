// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a35bf950207a.js');self.addEventListener('install',()=>self.skipWaiting());