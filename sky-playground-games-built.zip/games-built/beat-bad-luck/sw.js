// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7f29e0de662a.js');self.addEventListener('install',()=>self.skipWaiting());