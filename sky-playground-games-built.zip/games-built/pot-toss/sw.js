// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-5b0c4915c5a0.js');self.addEventListener('install',()=>self.skipWaiting());