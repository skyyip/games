// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-2fb4ab4dbd4a.js');self.addEventListener('install',()=>self.skipWaiting());