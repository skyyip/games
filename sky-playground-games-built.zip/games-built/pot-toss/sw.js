// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a52e63d07300.js');self.addEventListener('install',()=>self.skipWaiting());