// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7dfb5f05fe70.js');self.addEventListener('install',()=>self.skipWaiting());