// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-807ffa6156d9.js');self.addEventListener('install',()=>self.skipWaiting());