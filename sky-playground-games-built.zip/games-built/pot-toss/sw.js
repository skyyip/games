// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b37025de7e0d.js');self.addEventListener('install',()=>self.skipWaiting());