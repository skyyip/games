// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-3b24e9bc30b0.js');self.addEventListener('install',()=>self.skipWaiting());