// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-56b153e1c4de.js');self.addEventListener('install',()=>self.skipWaiting());