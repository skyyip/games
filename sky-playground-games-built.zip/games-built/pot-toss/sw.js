// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-27cd5b5aa633.js');self.addEventListener('install',()=>self.skipWaiting());