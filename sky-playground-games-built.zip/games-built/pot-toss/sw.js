// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b1ba6ac4e45c.js');self.addEventListener('install',()=>self.skipWaiting());