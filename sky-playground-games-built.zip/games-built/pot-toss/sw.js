// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f0dcbb43a5b7.js');self.addEventListener('install',()=>self.skipWaiting());