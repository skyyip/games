// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-963197fc16d1.js');self.addEventListener('install',()=>self.skipWaiting());