// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e947133c9c3a.js');self.addEventListener('install',()=>self.skipWaiting());