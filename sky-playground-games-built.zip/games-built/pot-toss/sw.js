// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7fc9ddc61ebe.js');self.addEventListener('install',()=>self.skipWaiting());