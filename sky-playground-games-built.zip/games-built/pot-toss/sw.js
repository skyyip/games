// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a647b64ac273.js');self.addEventListener('install',()=>self.skipWaiting());