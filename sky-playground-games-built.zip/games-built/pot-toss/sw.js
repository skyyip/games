// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c50f4f3ffcfb.js');self.addEventListener('install',()=>self.skipWaiting());