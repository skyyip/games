// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e785ce528a63.js');self.addEventListener('install',()=>self.skipWaiting());