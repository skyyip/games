// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-3fc01b6f4e06.js');self.addEventListener('install',()=>self.skipWaiting());