// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a93b21eef380.js');self.addEventListener('install',()=>self.skipWaiting());