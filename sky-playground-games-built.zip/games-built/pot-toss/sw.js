// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-3566a1f150a6.js');self.addEventListener('install',()=>self.skipWaiting());