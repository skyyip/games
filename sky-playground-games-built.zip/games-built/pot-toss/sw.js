// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-92cd9c2ecdb4.js');self.addEventListener('install',()=>self.skipWaiting());