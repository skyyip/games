// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-6615a9e0b13e.js');self.addEventListener('install',()=>self.skipWaiting());