// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-e85b1dfe76b2.js');self.addEventListener('install',()=>self.skipWaiting());