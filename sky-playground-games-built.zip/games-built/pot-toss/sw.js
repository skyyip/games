// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7d48b79bf9da.js');self.addEventListener('install',()=>self.skipWaiting());