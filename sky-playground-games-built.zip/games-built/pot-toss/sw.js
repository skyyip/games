// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7921f28cd196.js');self.addEventListener('install',()=>self.skipWaiting());