// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1845ced6ecea.js');self.addEventListener('install',()=>self.skipWaiting());