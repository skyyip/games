// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c9f445f68ad7.js');self.addEventListener('install',()=>self.skipWaiting());