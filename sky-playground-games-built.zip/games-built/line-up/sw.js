// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-4a1bcddb6f79.js');self.addEventListener('install',()=>self.skipWaiting());