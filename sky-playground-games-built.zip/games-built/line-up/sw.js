// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ec02da9abc76.js');self.addEventListener('install',()=>self.skipWaiting());