// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-df3ba1c1d144.js');self.addEventListener('install',()=>self.skipWaiting());