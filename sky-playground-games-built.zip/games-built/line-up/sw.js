// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-baedde0a1422.js');self.addEventListener('install',()=>self.skipWaiting());