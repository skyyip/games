// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-4309e6b5db12.js');self.addEventListener('install',()=>self.skipWaiting());