// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-bdfe86a11ce0.js');self.addEventListener('install',()=>self.skipWaiting());