// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-8e13c58158d5.js');self.addEventListener('install',()=>self.skipWaiting());