// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b18a5cb25659.js');self.addEventListener('install',()=>self.skipWaiting());