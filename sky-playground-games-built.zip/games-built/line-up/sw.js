// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-46bfd3af7612.js');self.addEventListener('install',()=>self.skipWaiting());