// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-33dad8a4215b.js');self.addEventListener('install',()=>self.skipWaiting());