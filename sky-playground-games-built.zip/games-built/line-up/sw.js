// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0fc4b2363fb1.js');self.addEventListener('install',()=>self.skipWaiting());