// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1f308ff967e4.js');self.addEventListener('install',()=>self.skipWaiting());