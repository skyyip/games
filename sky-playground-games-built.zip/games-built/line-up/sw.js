// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-77dac8e73e0f.js');self.addEventListener('install',()=>self.skipWaiting());