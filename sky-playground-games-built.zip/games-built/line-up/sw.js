// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1113c4e974db.js');self.addEventListener('install',()=>self.skipWaiting());