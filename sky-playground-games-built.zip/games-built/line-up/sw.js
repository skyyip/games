// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b9276a973c69.js');self.addEventListener('install',()=>self.skipWaiting());