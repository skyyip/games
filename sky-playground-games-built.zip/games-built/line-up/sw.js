// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-16088f1205f6.js');self.addEventListener('install',()=>self.skipWaiting());