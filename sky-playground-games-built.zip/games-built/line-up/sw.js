// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-362d14423a05.js');self.addEventListener('install',()=>self.skipWaiting());