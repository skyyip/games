// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-97ef00b87ea8.js');self.addEventListener('install',()=>self.skipWaiting());