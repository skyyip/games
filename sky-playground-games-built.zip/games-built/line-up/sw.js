// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7d410e2ce0b4.js');self.addEventListener('install',()=>self.skipWaiting());