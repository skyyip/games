// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-fc9484904c4f.js');self.addEventListener('install',()=>self.skipWaiting());