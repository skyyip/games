// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-58b16e1ca6ea.js');self.addEventListener('install',()=>self.skipWaiting());