// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-62cc684bb86f.js');self.addEventListener('install',()=>self.skipWaiting());