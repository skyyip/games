// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-dd4bcb35891d.js');self.addEventListener('install',()=>self.skipWaiting());