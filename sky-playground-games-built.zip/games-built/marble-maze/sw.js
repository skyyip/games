// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d5e3a78b4f11.js');self.addEventListener('install',()=>self.skipWaiting());