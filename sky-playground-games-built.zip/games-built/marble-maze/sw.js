// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-3997b3a6afb6.js');self.addEventListener('install',()=>self.skipWaiting());