// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-cd30f246ac16.js');self.addEventListener('install',()=>self.skipWaiting());