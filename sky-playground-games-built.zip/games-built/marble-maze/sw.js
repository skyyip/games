// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-95b3ff1a1c76.js');self.addEventListener('install',()=>self.skipWaiting());