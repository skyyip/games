// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9def572130fd.js');self.addEventListener('install',()=>self.skipWaiting());