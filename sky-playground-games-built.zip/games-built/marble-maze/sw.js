// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-ccb10870da2b.js');self.addEventListener('install',()=>self.skipWaiting());