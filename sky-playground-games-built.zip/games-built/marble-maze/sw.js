// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-3c9465d6778e.js');self.addEventListener('install',()=>self.skipWaiting());