// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-aabc0bfe2a19.js');self.addEventListener('install',()=>self.skipWaiting());