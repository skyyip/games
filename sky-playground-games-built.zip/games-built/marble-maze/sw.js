// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-78b07d308c5a.js');self.addEventListener('install',()=>self.skipWaiting());