// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-90ffeb73407a.js');self.addEventListener('install',()=>self.skipWaiting());