// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-63bc201592f5.js');self.addEventListener('install',()=>self.skipWaiting());