// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7fb5078b0ee2.js');self.addEventListener('install',()=>self.skipWaiting());