// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-434f157e1fa1.js');self.addEventListener('install',()=>self.skipWaiting());