// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-7880cd5b7bac.js');self.addEventListener('install',()=>self.skipWaiting());