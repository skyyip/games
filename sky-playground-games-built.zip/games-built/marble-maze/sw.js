// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-c59cd7636e7d.js');self.addEventListener('install',()=>self.skipWaiting());