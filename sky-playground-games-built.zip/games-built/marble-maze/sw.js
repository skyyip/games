// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0a5c0bdf32f8.js');self.addEventListener('install',()=>self.skipWaiting());