// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a4c22765a7ad.js');self.addEventListener('install',()=>self.skipWaiting());