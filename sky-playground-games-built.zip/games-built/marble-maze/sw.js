// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-9fdb1d9311bd.js');self.addEventListener('install',()=>self.skipWaiting());