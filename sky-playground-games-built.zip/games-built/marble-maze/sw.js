// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0181bb199eab.js');self.addEventListener('install',()=>self.skipWaiting());