// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f0c0f036c35e.js');self.addEventListener('install',()=>self.skipWaiting());