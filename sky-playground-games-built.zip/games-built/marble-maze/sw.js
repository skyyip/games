// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b64b94e21d25.js');self.addEventListener('install',()=>self.skipWaiting());