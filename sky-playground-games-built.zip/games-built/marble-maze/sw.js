// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-13c7640f5fe5.js');self.addEventListener('install',()=>self.skipWaiting());