// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a1e2863ab217.js');self.addEventListener('install',()=>self.skipWaiting());