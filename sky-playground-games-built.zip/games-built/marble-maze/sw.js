// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-71e1377dae18.js');self.addEventListener('install',()=>self.skipWaiting());