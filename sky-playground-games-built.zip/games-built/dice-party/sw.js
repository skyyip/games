// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f02130ed5ef4.js');self.addEventListener('install',()=>self.skipWaiting());