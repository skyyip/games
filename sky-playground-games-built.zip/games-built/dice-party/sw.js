// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-91473ac197c6.js');self.addEventListener('install',()=>self.skipWaiting());