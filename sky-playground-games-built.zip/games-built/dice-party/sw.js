// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-beb6ec16e98f.js');self.addEventListener('install',()=>self.skipWaiting());