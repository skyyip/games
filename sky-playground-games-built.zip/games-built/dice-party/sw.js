// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d162c0ff51a1.js');self.addEventListener('install',()=>self.skipWaiting());