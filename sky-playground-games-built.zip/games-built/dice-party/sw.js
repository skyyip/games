// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a7d3fe8c6859.js');self.addEventListener('install',()=>self.skipWaiting());