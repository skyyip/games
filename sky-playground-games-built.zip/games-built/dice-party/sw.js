// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b388292395dc.js');self.addEventListener('install',()=>self.skipWaiting());