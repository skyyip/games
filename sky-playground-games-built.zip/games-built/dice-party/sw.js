// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-60a43fb5d710.js');self.addEventListener('install',()=>self.skipWaiting());