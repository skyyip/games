// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-dab154464666.js');self.addEventListener('install',()=>self.skipWaiting());