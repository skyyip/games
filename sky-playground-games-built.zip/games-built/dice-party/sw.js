// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-d4dc8f2e32a3.js');self.addEventListener('install',()=>self.skipWaiting());