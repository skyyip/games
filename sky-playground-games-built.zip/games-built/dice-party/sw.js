// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-bdce5b664d65.js');self.addEventListener('install',()=>self.skipWaiting());