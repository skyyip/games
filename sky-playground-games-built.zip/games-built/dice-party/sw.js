// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a6caa16100c2.js');self.addEventListener('install',()=>self.skipWaiting());