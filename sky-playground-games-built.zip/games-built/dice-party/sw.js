// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-630d8f9add20.js');self.addEventListener('install',()=>self.skipWaiting());