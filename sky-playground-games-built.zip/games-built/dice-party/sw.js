// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f0b89968dacf.js');self.addEventListener('install',()=>self.skipWaiting());