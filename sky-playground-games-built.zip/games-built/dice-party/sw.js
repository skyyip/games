// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1ded9f625251.js');self.addEventListener('install',()=>self.skipWaiting());