// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-25b832eb3618.js');self.addEventListener('install',()=>self.skipWaiting());