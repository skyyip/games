// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-1dda69a07577.js');self.addEventListener('install',()=>self.skipWaiting());