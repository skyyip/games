// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-f0310877be20.js');self.addEventListener('install',()=>self.skipWaiting());