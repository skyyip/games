// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-0bf5b935a0d4.js');self.addEventListener('install',()=>self.skipWaiting());