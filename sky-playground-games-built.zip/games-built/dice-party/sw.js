// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-713b97032dcc.js');self.addEventListener('install',()=>self.skipWaiting());