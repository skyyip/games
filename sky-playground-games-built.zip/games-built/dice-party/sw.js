// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-b154d794ebbb.js');self.addEventListener('install',()=>self.skipWaiting());