// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-24c27ce64967.js');self.addEventListener('install',()=>self.skipWaiting());