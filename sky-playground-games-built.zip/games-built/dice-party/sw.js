// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-5741ca6dc15e.js');self.addEventListener('install',()=>self.skipWaiting());