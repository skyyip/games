// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-3e806b898833.js');self.addEventListener('install',()=>self.skipWaiting());