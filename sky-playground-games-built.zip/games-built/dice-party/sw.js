// Upgrade bridge for previously installed service workers. Application assets use content hashes.
importScripts('./sw-a370a9d2cb15.js');self.addEventListener('install',()=>self.skipWaiting());